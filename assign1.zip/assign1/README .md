Storage Manager
------------------------------

Members of the team
------------------------------
1) Harshavardhan Soma (A20551364)

2) Visvesh Kumar Yallamelli (A20564714)

3) Haritha Borra (A20610602)



CONTRIBUTION OF THE TEAM
--------------------------------------

CWID                  NAME                        CONTRIBUTION DESCRIPTION                                   PERCENT CONTRIBUTION
A20551364        HARSHAVARDHAN SOMA             Creating Page File, Write Operations                                    33.3%
A20564714      VISVESH KUMAR YALLAMELLI         Open, close, destroy an existing pagefile, Read operations              33.3%
A20610602        HARIITHA BORRA                 Read Operations                                                         33.3%


# RUNNING THE MAKEFILE

- Open code editor
- Open terminal
- Run “make clean” to clean the compiled files, executable files and log files if there is any:
- Type "make" to indicates that the compilation and linking steps were successful.
- Type "make run" executes a target defined in the Makefile that runs the compiled program. 


# INCLUDED FILES:

	Makefile
	README.md
	storage_mgr.c
	storage_mgr.h
	storage_mgr.o
	dberror.c
  storage_mgr.png
	dberror.h
  dberror.o
	test_assign1_1.c
  test_assign1_1.o
  test_assign1.exe
	test_helper.h
  test_pagefile.bin

THE WORK DONE BY HARSHAVARDHAN SOMA (A20551364)

Aim
------------------------------------------------------------------------------------------
Implementing a storage manager that can read blocks from a disk file into memory and write blocks from memory to a disk file is the aim of this assignment. The file has blocks, or pages, are all the same size.

FILE(has Pages/Blocks) _READ_> Memory

Memory _WRITE_> File (Present on Disk)

The assignment includes the following different file operations:<br/>
* createPageFile()
* openPageFile() 
* closePageFile()
* destroyPageFile()

The functions of the read operation are: 
1. readBlock()
2. getBlockPos()
3. readFirstBlock() 
4. readPreviousBlock() 
5. readCurrentBlock() 
6. readNextBlock() 
7. readLastBlock()

The following are the write operations: 
1. writeBlock() 
2. writeCurrentBlock() 
3. appendEmptyBlock() 
4. ensureCapacity()

The following files are supplied for the assignment: 
I) dberror.h -> The header file containing all of the error message constants
ii) dberror.c -> error message function definition. 
iii) storage_mgr.h -> Header file containing all declared functions in .C
iv) Test_assign1_1.c -> Code test cases

The following files need to be made: 
i) storage_mgr.c -> Describe every read, write, file, and other operations.

This assignment involves two primary and significant data structures: 
1. File Handle (SM_FileHandle) and, 
2. Page Handle (SM_PageHandle)

An open page file with the following information is represented by a file handle. 
1) Name of the file 
2) Total pages 
3) Position of the Current Page 
4) mgmtInfo -> It keeps the extra details about the file.

A page handle is a pointer to the memory location where a page's contents are kept.

1. createPageFile()
------------------------------------------------------------------------------------------
The goal is to create a new file and set it up with a blank page of data.

- The file is opened in write mode.
- If the file cannot be opened, it returns RC_FILE_NOT_FOUND. 
- Allocates memory for one page using calloc
  (ensuring the memory  is initialized to zero). 
- Uses fwrite to write the empty page to the file. 
- Returns RC_OK and closes the file upon success.
- On failure, returns RC_WRITE_FAILED.

2. openPageFile()
------------------------------------------------------------------------------------------
Purpose: The SM_FileHandle structure is initialized and an existing file is opened.

- The file is opened in read/write mode.
- If the file cannot be opened, it returns RC_FILE_NOT_FOUND. 
- Initializes curPagePos to 0 (signaling the first page) and sets the fileName.
- Determines the file size in order to calculate the total number of pages. 
- For upcoming actions, the file pointer is saved in the mgmtInfo field. 
- Upon success, returns RC_OK.

3. closePageFile()
------------------------------------------------------------------------------------------
Purpose: Its goal is to close an open file.

- Uses the file pointer that is kept in mgmtInfo to close the file. 
- Upon success, returns RC_OK. 
- The file pointer is set to NULL if the file does not shut.

4. destroyPageFile()
------------------------------------------------------------------------------------------
Purpose: The given file is deleted.

- Uses the remove function to delete the file. 
- If the file deletion is successful, RC_OK is returned. 
- If the file is not removed or deleted, failure is assumed.

5. writeBlock
------------------------------------------------------------------------------------------
Goal: writes information to a designated file page.

- It confirms the page number.
- If the page number is incorrect, RC_WRITE_FAILED is returned. 
- Uses fseek to determine the correct file offset. 
- Uses fwrite to write data from memPage to the designated page in the file. 
- The current page is reflected by updating curPagePos. 
- Upon success, returns RC_OK.


************************************************ EXPLANATION OF READ OPERATIONS *********************************************

6. The readBlock function
------------------------------------------------------------------------------------------
The storage manager's readBlock() function reads a block from a file into memory.
The function uses the following arguments: pageNum, fHandle, and memPage.

The steps to follow inside the function are as follows:

* Verify that the page number supplied as an argument is genuine; if it is less than 0 or greater than the total number of pages, return
RC_READ_NON_EXISTING_PAGE. 
* Using mgmtInfo, create a pointer to the file that contains the extra data. 
* To locate or seek the page block, use fseek() with offset value(pageNum * PAGE_SIZE) 
* Once the file has been located, use fread() to read it and provide in parameters such as the file address from which the data will be read, the size of the element to be read, the number of elements to be read, and the pointer to the data store. 
* The current page position (currPagePos) should then be updated to the pageNum that is currently in use.

7. getBlockPos()
------------------------------------------------------------------------------------------
The purpose of the getBlockPos() function is to retrieve the file's page position. It uses fHandle as support. 
The stages are as follows:
* Return RC_FILE_HANDLE_NOT_INIT if the pointer fHandle is null or if the mgmtInfo from fHandle is null. 
* Return RC_READ_NON_EXISTING_PAGE if the currentPagePos is less than 1 or less than the totalNumPages.
* Return the currentPagePos, or the Block position in the file, at the conclusion.

8. readFirstBlock():
------------------------------------------------------------------------------------------
Its goal is to read the file's first block.

- Calling readBlock() with the page index set to 0 reads the first block. 
- The function readBlock(0, fHandle, memPage) is called.

9. readLastBlock():
------------------------------------------------------------------------------------------
Its goal is to read the file's final block.

- Calls readBlock() with the index of the final page (totalNumPages - 1) to read the final block. 
- ReadBlock(fHandle->totalNumPages - 1, fHandle, memPage) is the function that is called.

10. readPreviousBlock():
------------------------------------------------------------------------------------------
The block before the current block is read for this purpose.

- To read the previous block, decrement curPagePos by 1. 
- It returns an error for a non-existent page if the previous page number is less than 0. 
- readBlock(fHandle->curPagePos - 1, fHandle, memPage) is the function call.

11. readCurrentBlock():
------------------------------------------------------------------------------------------
Goal: Reads the file\'s current block.

- Uses curPagePos as the page number when using readBlock(). 
- ReadBlock(fHandle->curPagePos, fHandle, memPage) is the function call.

12. readNextBlock():
------------------------------------------------------------------------------------------
Its goal is to read the block that comes after the present block.

- To read the next block, increment curPagePos by 1. 
- It returns an error for a non-existing page if the subsequent page is longer than the total number of pages. 
- ReadBlock(fHandle->curPagePos + 1, fHandle, memPage) is the function call.
